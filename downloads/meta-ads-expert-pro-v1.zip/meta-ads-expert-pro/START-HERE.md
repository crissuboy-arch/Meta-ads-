# Meta Ads Expert PRO — Start here

Welcome. This package turns Claude into your Meta Ads media buyer: strategy, hooks, ad copy, audiences, tracking setup, and campaign creation inside your own Meta Ads account.

**You stay in control of your money.** Claude creates everything **paused**. Nothing spends until you tell it to turn the ads on.

It takes about 10 minutes to set up, once.

---

## Step 1 — Install this package in Claude

Add the `meta-ads-expert-pro` package (the folder or zip you received) to Claude as a plugin or as skills. Slash commands such as `/start` and `/publish` should then appear when you type `/`.

## Step 2 — Connect your Meta Ads account (the connector)

Claude creates campaigns through a connector called **Windsor.ai**. You connect your own Meta account there, so your password never goes through this package or through Claude.

1. In Claude, open **Settings → Connectors**, find **Windsor.ai** and add it.
2. Log in to Windsor.ai when asked and connect **Meta Ads (Facebook & Instagram Ads)** with your Facebook login. Choose your ad account.
3. Back in Claude, type: `Which ad accounts are connected in Windsor?` — you should see your Meta ad account.

> Windsor.ai is a separate service with its own plans and pricing. Check its current limits and price before you start; they are not included in your Meta Ads Expert PRO subscription.

## Step 3 — Have these ready

- Your **ad account** active in Meta Ads Manager with a payment method set.
- The **Facebook Page** that will run the ads, and its **Page ID**.
- Your **Pixel ID** (Events Manager → Data sources), if you will run sales campaigns.
- Your **sales page link** and your **creatives** (images or videos).
- If you advertise in the **EU, Brazil, Taiwan, Singapore, Thailand, Australia or India**: Meta requires verified beneficiary/payer details (Meta Business settings → Verified identities).

## Step 4 — Run it

Connect a folder in Claude (for example "Campaigns") so your work is saved, then type the commands in this order:

| Command | What it does |
|---|---|
| `/start` | Asks about your product and tells you where to begin |
| `/setup` | One-time setup: business, audience, budget, Page and Pixel |
| `/research [product]` | Maps your market, pains, objections and angles |
| `/creative [product]` | Writes 3 ad variations and scores each one |
| `/tracking` | Pixel + Conversions API + test events (do this before sales campaigns) |
| `/campaign [product]` | Builds the campaign structure and budget |
| `/publish [product]` | Creates it in Meta — **paused** |
| `/analyze [product]` | Reads real results after the test period |

Also available: `/hooks`, `/ugc`, `/audience`, `/offer`, `/ab-test`, `/audit`, `/market-research`.

## Your first campaign, in one message

> `/start` — "I sell [product] to [audience] in [country]. Budget is [amount] per day. My sales page is [link]."

## Safety rules built in

- Everything is created paused.
- Claude shows each level (campaign, ad set, ad) and waits for your yes.
- Turning ads on is a separate step, after Claude repeats your daily spend back to you.
- Claude never asks for your Facebook password or access token.
- There is no delete action. To remove something, pause it and delete it in Ads Manager.

## Honest expectations

Claude builds the structure, the copy and the tracking plan. It cannot promise sales. Results depend on your product, offer, market and budget. Run the test for at least 3-4 days before changing anything.

## Troubleshooting

- **Windsor does not show my Meta account** → repeat Step 2, point 2.
- **An action fails** → read the error Claude shows. Common causes: missing Page ID, a Pixel without a Purchase event, or missing regional identities (EU/Brazil and others).
- **Ads rejected** → Claude reads Meta's reason, fixes only that point and asks before resubmitting.
- **Anything else** → contact support using the email on your Hotmart receipt.
